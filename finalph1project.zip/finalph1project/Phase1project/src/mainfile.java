import java.io.IOException;
import java.util.Scanner;

public class mainfile {
	
	public static void main(String[] args) throws IOException{
		Scanner sc=new Scanner(System.in);
		
		addingfile a=new addingfile();
		displaythefile dis=new displaythefile();
		deletingfile del=new deletingfile();
		searchthefile s=new searchthefile();
		
		label1:while(true) {
			System.out.println("Enter your choice to enter into main switch case ");
			int choice=sc.nextInt();
			switch(choice) {
			case 1:dis.displayTheFile();
			break;
			case 2:while(true) {
				System.out.println("enter subswitch option ");
				int choice1=sc.nextInt();
				switch(choice1){
				case 1:a.addToFile();
				break;
				case 2:del.deleteTheFile();
				break;
				case 3:s.searchTheFile();
				break;
				case 4:continue label1;
				default:System.out.println("Exit from sub switch case");
				break;
				}
				
			}
			case 3:System.exit(0);
			break;
			default:System.out.println("invalid operation");
			}
		}
		
		
		
		
	}

}

