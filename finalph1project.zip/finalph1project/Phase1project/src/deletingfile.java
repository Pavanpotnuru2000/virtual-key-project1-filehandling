import java.io.File;
import java.util.Scanner;

public class deletingfile {
	public void deleteTheFile() {
		String path="C:\\Users\\Pavan Potnuru\\OneDrive\\Desktop\\finalph1project\\files";
		displaythefile df=new displaythefile();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter file name to delete");
		String filename=sc.nextLine();
		String filepath=path+filename;
		
		File f=new File(filepath);
		if(f.delete()) {
			System.out.println("file deleted successfully");
		}
		else {
			System.out.println("No File Found");
		}
	}

}
