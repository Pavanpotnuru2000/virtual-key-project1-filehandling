
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class addingfile {
	public void addToFile() {
		String path="C:\\Users\\Pavan Potnuru\\OneDrive\\Desktop\\finalph1project\\files";
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter filename to add ");
		String filename=sc.nextLine();
		String filepath=path+filename;
		File f=new File(filepath);
		try {
			if(f.createNewFile()) {
				System.out.println("file is created successfully");
			}
			else {
				System.out.println("file not created");
			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}

		
	}

}
