
import java.io.File;

public class displaythefile {
	public void displayTheFile() {
		String path="C:\\Users\\Pavan Potnuru\\OneDrive\\Desktop\\finalph1project\\files";
		File f=new File(path);
		File[] files=f.listFiles();
		for(File ff:files) {
			System.out.println(ff.getName());
		}
		System.out.println();
	}

}
