
import java.io.File;
import java.util.Scanner;

public class searchthefile {
	public void searchTheFile() {
		String path="C:\\Users\\Pavan Potnuru\\OneDrive\\Desktop\\finalph1project\\files";
		displaythefile df=new displaythefile();
		df.displayTheFile();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter file name to search ");
		String filename=sc.nextLine();
		String filepath=path+filename;
		File f=new File(filepath);
		File f1=new File(path);
		File[] files=f1.listFiles();
		
		int flag=0;
		for(File ff:files) {
			if(ff.getName().equals(f.getName())) {
				flag=1;
				break;
			}
			else
				flag=0;
		}
		
		if(flag==0) {
			System.out.println("file is found");
		}
		else {
			System.out.println("File Not Found");
		}

		}

}
